<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct() {
        parent::__construct();
    }

    public function index()
	{
		$this->load->view('login_view');
	}

	public function checkEmail()
	{
		$post = $this->input->post();
		$response = ['status'=>FALSE, 'data'=>NULL, 'message'=>'Invalid Parameters'];
		$status = [];
		// check user is empty
		// array_walk($post, create_function('&$val', '$val = trim($val);'));
		if(!empty($post['email']))
		{
			// get user from db by username
			$record = $this->CommonModel->getRow('user', array('email'=>$post['email']));
			if(!empty($record))
			{
				$response = ['status'=>TRUE, 'data'=>'', 'message'=>'User present.'];
			}
			else
			{
				$sess_data = array(
					'email' => $post['email']
				);
				// set session in aplication
				$this->session->set_userdata($sess_data);
				$response = ['status'=>TRUE, 'data'=>'Login/signUpView', 'message'=>'User not present.'];
			}
		}
		echo json_encode($response);
	}

	public function validate()
	{
		$post = $this->input->post();
		$response = ['status'=>FALSE, 'data'=>NULL, 'message'=>'Invalid Parameters'];
		$status = [];
		// check user is empty
		// array_walk($post, create_function('&$val', '$val = trim($val);'));
		if(!empty($post['email']) && !empty($post['password']))
		{
			// get user from db by username
			$record = $this->CommonModel->getRow('user', array('email'=>$post['email'], 'password'=>md5($post['password'])));
			if(!empty($record))
			{
				$sess_data = array(
					'id' => $record['id'],
					'first_name' => $record['first_name'],
					'last_name' => $record['last_name'],
					'email' => $record['email'],
					'password' => $record['password'],
					'dept_id' => $record['dept_id'],
					'sub_dept_id' => $record['sub_dept_id'],
					'is_user_login' => 1
				);
				// set session in aplication
				$this->session->set_userdata($sess_data);
				$response = ['status'=>TRUE, 'data'=>'Dashboard', 'message'=>'User present.'];
			}
		}
		echo json_encode($response);
	}

	public function signUpView()
	{
		$this->load->view('sign_up_view');
	}

	public function saveUser()
	{
		$post = $this->input->post();
		$response = ['status'=>FALSE, 'data'=>NULL, 'message'=>'Invalid Parameters'];
		$status = [];
		// check user is empty
		// array_walk($post, create_function('&$val', '$val = trim($val);'));
		if(!empty($post['first_name']) && !empty($post['last_name']) && !empty($post['email']) && !empty($post['password']))
		{
			// get user from db by username
			$post['password'] = md5($post['password']);
			$res = $this->CommonModel->add('user', $post);
			if(!empty($res))
			{
				$response = ['status'=>TRUE, 'data'=>'Login', 'message'=>'User saved successfully.'];
			}
			else
			{
				$response = ['status'=>FALSE, 'data'=>NULL, 'message'=>'Something went wrong.'];
			}
		}
		echo json_encode($response);
	}

	public function logout()
	{
		$user_data = $this->session->get_userdata();
		$this->session->sess_destroy();
		$sess_data = array(
			'id' => '',
			'first_name' => '',
			'last_name' => '',
			'email' => '',
			'password' => '',
			'dept_id' => '',
			'sub_dept_id' => '',
			'is_user_login' => 0
		);
		$this->session->set_userdata($sess_data);
		$this->session->unset_userdata(array('id','first_name','lasr_name','email','password','dept_id','sub_dept_id','is_user_login'));
		redirect('login');
	}

}
?>