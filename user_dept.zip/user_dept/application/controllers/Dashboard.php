<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct() {
        parent::__construct();
    }

    public function index()
	{
		$data = array();
		$id = $this->session->userdata('id');
		$data['user'] = $this->CommonModel->getRow('user', array('id' => $id));
		if(!empty($data['user']['dept_id']))
		{
			$department = $this->CommonModel->getRow('dept', array('id' => $data['user']['dept_id']), 'dept_name');	
			$data['user']['department'] = $department['dept_name'];
		}
		if(!empty($data['user']['sub_dept_id']))
		{
			$sub_department = $this->CommonModel->getRow('sub_dept', array('id' => $data['user']['sub_dept_id']), 'sub_dept_name');
			$data['user']['sub_department'] = $sub_department['sub_dept_name'];
		}
		$hdata['heading'] = 'User Profile';
        $hdata['data'] = $data;
        $hdata['view'] = 'dashboard_view';
        $this->load->view('include/header', $hdata);
	}

	public function getDepartments()
	{
		$records = $this->CommonModel->getRecords('dept');
		$response = ['status'=>TRUE, 'data'=>$records, 'message'=>'Data not Present'];
		echo json_encode($response);
	}

	public function getSubDepartments()
	{
		$post = $this->input->post();
		$response = ['status'=>FALSE, 'data'=>NULL, 'message'=>'Invalid Inputs'];
		if(!empty($post['dept_id']))
		{
			$records = $this->CommonModel->getRecords('sub_dept', array('dept_id' => $post['dept_id']));
			$response = ['status'=>TRUE, 'data'=>$records, 'message'=>'Data not Present'];
		}
		echo json_encode($response);
	}

	public function updateUser()
	{
		$post = $this->input->post();
		$response = ['status'=>FALSE, 'data'=>NULL, 'message'=>'Invalid Inputs'];
		if(empty($post['dept_id']) && empty($post['sub_dept_id']) && empty($_FILES) || empty($post['id']))
		{
			goto end;
		}
		else
		{
			if (!empty($_FILES))
			{
				if (!empty($_FILES['userfile']['size'] != 0))
				{
					$file_array = explode('.', $_FILES['userfile']['name']);
					$post['image'] = $post['id'].'.'.$file_array[1];
					$_FILES['userfile']['name'] = $post['image'];
					$upload_path = FCPATH . 'assets/img/';
					if(file_exists($upload_path.$post['image']))
					{
						unlink($upload_path.$post['image']);
					}
					$config = array(
						'upload_path' => $upload_path,
						'allowed_types' => "jpg|png|jpeg",
						'overwrite' => TRUE,
						'max_size' => "2048000"
					);
					$this->upload->initialize($config);
					$result = $this->upload->do_upload('userfile');
					if(empty($result))
					{
						unset($post['image']);
					}
				}
			}
			$record = $this->CommonModel->edit('user', $post, array('id'=>$post['id']));
			if(!empty($record))
			{
				$response['status'] = TRUE;
				$response['message'] ='User saved successfully.';
			}
			else
			{
				$response['message'] = 'Something went wrong';
			}
		}
		end:
		echo json_encode($response);
	}
}
?>