<?php

class CommonModel extends CI_Model {

    public function add($tbl = NULL, $record = NULL) {
        if (!empty($tbl) && !empty($record)) {
            $this->db->insert($tbl, $record);
            return $this->db->insert_id();
        } else {
            return FALSE;
        }
    }

    public function multipleAdd($tbl = NULL, $records = NULL) {
        $records = array_values($records);
        if (!empty($tbl) && !empty($records)) {
            $res = $this->db->insert_batch($tbl, $records);
            return $res;
        } else {
            return FALSE;
        }
    }

    public function edit($tbl = NULL, $record = NULL, $cond = NULL) {
        if (!empty($tbl) && !empty($record) && !empty($cond)) {
            $res = $this->db->update($tbl, $record, $cond);
            return $res;
        } else {
            return FALSE;
        }
    }

    public function multipleEdit($tbl = NULL, $record = NULL, $col = NULL) {
        if (!empty($tbl) && !empty($record)) {
            $res = $this->db->update_batch($tbl, $record, $col);
            return $res;
        } else {
            return FALSE;
        }
    }

    public function delete($tbl = NULL, $cond = NULL) {
        if (!empty($tbl) && !empty($cond)) {
            $this->db->where($cond);
            $res = $this->db->delete($tbl);
            return $res;
        } else {
            return FALSE;
        }
    }

    public function multipleDelete($tbl = NULL, $column = NULL, $value = NULL) {
        if (!empty($tbl) && !empty($column) && !empty($value)) {
            $this->db->where_in($column, $value);
            $res = $this->db->delete($tbl);
            return $res;
        } else {
            return FALSE;
        }
    }

    public function getRow($tbl = NULL, $cond = NULL, $cols = NULL, $order_col = NULL, $order_by = NULL) {
        if (!empty($tbl)) {
            if (!empty($cols)) {
                $this->db->select($cols);
            }
            if (!empty($order_col) && !empty($order_by)) {
                $this->db->order_by($order_col, $order_by);
            }
            if (!empty($cond)) {
                $res = $this->db->get_where($tbl, $cond)->row_array();
            } else {
                $res = $this->db->get($tbl)->row_array();
            }
            return $res;
        } else {
            return FALSE;
        }
    }

    // get multiple records from the table
    public function getRecords($tbl = NULL, $cond = NULL, $cols = NULL, $limit = NULL, $order_col = NULL, $order_by = NULL, $group_by = NULL) {
        if (!empty($tbl)) {
            if (!empty($cols)) {
                $this->db->select($cols);
            }
            if (!empty($limit)) {
                $this->db->limit($limit);
            }
            if (!empty($order_col) && !empty($order_by)) {
                $this->db->order_by($order_col, $order_by);
            }
            if (!empty($cond)) {
                $this->db->where($cond);
            }
            if (!empty($group_by)) {
                $this->db->group_by($group_by);
            }
            $res = $this->db->get($tbl)->result_array();

            return $res;
        } else {
            return FALSE;
        }
    }

    public function searchByLike($tbl = NULL, $column = NULL, $match = NULL, $cols = NULL, $cond = NULL, $limit = NULL) {
        if (!empty($tbl)) {
            if (!empty($cols)) {
                $this->db->select($cols);
            }
            if (!empty($limit)) {
                $this->db->limit($limit);
            }
            if (!empty($column) && !empty($match)) {
                $this->db->like($column, $match);
            }
            if (!empty($cond)) {
                $this->db->where($cond);
            }
            $res = $this->db->get($tbl)->result_array();
            return $res;
        } else {
            return FALSE;
        }
    }

    public function getRecordCount($tbl = NULL, $cond = NULL) {
        if (!empty($cond)) {
            $this->db->where($cond);
        }
        $res = $this->db->count_all_results($tbl);
        return $res;
    }

    public function getLastRecord($tbl = NULL, $cols = NULL) {
        if (!empty($tbl)) {
            if (!empty($cols)) {
                $this->db->select($cols);
            } else {
                $this->db->select('*');
            }
            $this->db->from($tbl);
            $this->db->order_by('id', 'DESC');
            $this->db->limit('1');
            $get = $this->db->get();
            return $get->row_array();
        }
    }

}
?>