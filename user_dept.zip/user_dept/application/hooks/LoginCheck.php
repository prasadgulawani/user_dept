<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginCheck {

	private $CI;

	function __construct() {
        $this->CI = & get_instance();
        if(!isset($this->CI->session))
        {  //Check if session lib is loaded or not
           	$this->CI->load->library('session');  //If not loaded, then load it here
        }
    }

    public function validateLogin()
	{
		if($this->CI->uri->segment(1) != 'login')
		{
			if(!$this->CI->session->userdata('is_user_login'))
			{
				redirect('login/logout');
			}
		}
	}
}
?>