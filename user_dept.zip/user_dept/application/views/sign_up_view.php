<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>SignUp User Dept</title>
    <!-- Bootstrap core CSS-->
    <link href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url(); ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url(); ?>assets/css/sb-admin.css" rel="stylesheet">
  </head>

  <body class="bg-dark">
    <div class="container">
      <div class="card card-login mx-auto mt-5">
        <div class="card-header">Sign Up</div>
        <div class="card-body">
          <form id="sign_up_form">
            <div class="form-group">
              <label for="first_name">First Name</label>
              <input class="form-control" id="first_name" name="first_name" type="text" aria-describedby="first_nameHelp" placeholder="Enter First Name">
            </div>

            <div class="form-group">
              <label for="last_name">Last Name</label>
              <input class="form-control" id="last_name" name="last_name" type="text" aria-describedby="last_nameHelp" placeholder="Enter Last Name">
            </div>

            <div class="form-group">
              <label for="email">Email address</label>
              <input class="form-control" id="email" name="email" type="email" aria-describedby="emailHelp" placeholder="Enter email" readonly value="<?php echo @$_SESSION['email'] ?>">
            </div>

            <div class="form-group">
              <label for="password">Password</label>
              <input class="form-control" id="password" name="password" type="password" aria-describedby="passwordHelp" placeholder="Enter password">
            </div>
            <button class="btn btn-primary btn-block" id="btn_sign_up">Save</button>
          </form>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url(); ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/common.js"></script>
  </body>

</html>
<script type="text/javascript">
  var base_url = '<?php echo base_url(); ?>';

  $('#btn_sign_up').on('click', function(e) {
    e.preventDefault();
    var first_name = $.trim($('#first_name').val());
    var last_name = $.trim($('#last_name').val());
    var email = $.trim($('#email').val());
    var password = $.trim($('#password').val());
    if(first_name == '' || first_name.length < 3)
    {
      alert('Please valid enter First Name.');
      return false;
    }
    else if(last_name == '' || last_name.length < 3)
    {
      alert('Please valid enter Last Name.');
      return false;
    }
    else if(email == '' || !validateEmail(email))
    {
      alert('Please valid enter Email.');
      return false;
    }
    else if(password == '' || password.length < 6)
    {
      alert('Please valid enter Password.');
      return false;
    }
    else
    {
      $('#btn_sign_up').attr('disabled', true);
      $.ajax({
        type: "POST",
        url: base_url+'login/saveUser',
        data: {'first_name': first_name, 'last_name': last_name, 'email': email, 'password': password},
        dataType: "json",
        success: function(response)
        {
          $('#btn_sign_up').removeAttr('disabled');
          alert(response.message);
          if(response.status == true)
          {
            window.location.href = base_url + response.data;
          }
        },
        error: function(response)
        {
          alert('Error posting feeds.');
          return false;
        }
      });
    }
  });
</script>