<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Login User Dept</title>
    <!-- Bootstrap core CSS-->
    <link href="<?php echo base_url(); ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url(); ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url(); ?>assets/css/sb-admin.css" rel="stylesheet">
  </head>

  <body class="bg-dark">
    <div class="container">
      <div class="card card-login mx-auto mt-5">
        <div class="card-header">Login</div>
        <div class="card-body">
          <form id="login_form">
            <div class="form-group">
              <label for="email">Email address</label>
              <input class="form-control" id="email" name="email" type="email" aria-describedby="emailHelp" placeholder="Enter email">
            </div>

            <div class="form-group d-none" id="pwd-div">
              <label for="password">Password</label>
              <input class="form-control" id="password" name="password" type="password" aria-describedby="passwordHelp" placeholder="Enter password">
            </div>
            <button class="btn btn-primary btn-block" id="btn_check">Check</button>
            <button class="btn btn-primary btn-block d-none" id="btn_login">Login</button>
          </form>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url(); ?>assets/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url(); ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/js/common.js"></script>
  </body>

</html>
<script type="text/javascript">
  var base_url = '<?php echo base_url(); ?>';

  $('#btn_check').on('click', function(e) {
    e.preventDefault();
    var email = $.trim($('#email').val());
    if(email == '' || !validateEmail(email))
    {
      alert('Please enter valid Email.');
      return false;
    }
    else
    {
      $('#btn_check').attr('disabled', true);
      $.ajax({
        type: "POST",
        url: base_url+'login/checkEmail',
        data: {'email': email},
        dataType: "json",
        success: function(response)
        {
          if(response.status == false)
          {
            alert(response.message);
            $('#btn_check').removeAttr('disabled');
          }
          else
          {
            if(response.data != '')
            {
              window.location.href = base_url + response.data;
            }
            else
            {
              $('#btn_check').removeAttr('disabled');
              $('#btn_check').addClass('d-none');
              $('#btn_login').removeClass('d-none');
              $('#pwd-div').removeClass('d-none');
            }
          }
        },
        error: function(response)
        {
          alert('Error posting feeds.');
          return false;
        }
      });
    }
  });

  $('#btn_login').on('click', function(e) {
    e.preventDefault();
    var email = $.trim($('#email').val());
    var password = $.trim($('#password').val());
    if(email == '' || !validateEmail(email))
    {
      alert('Please enter valid Email.');
      return false;
    }
    else if(password == '')
    {
      alert('Please enter Password.');
      return false;
    }
    else
    {
      $('#btn_login').attr('disabled', true);
      $.ajax({
        type: "POST",
        url: base_url+'login/validate',
        data: {'email': email, 'password': password},
        dataType: "json",
        success: function(response)
        {
          if(response.status == false)
          {
            alert(response.message);
            $('#password').val('');
            $('#btn_login').removeAttr('disabled');
          }
          else
          {
            window.location.href = base_url + response.data;
          }
        },
        error: function(response)
        {
          alert('Error posting feeds.');
          return false;
        }
      });
    }
  });
</script>