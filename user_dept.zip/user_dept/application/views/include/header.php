<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>User - Dashboard</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url('assets'); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url('assets'); ?>/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url('assets'); ?>/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <link href="<?php echo base_url('assets'); ?>/vendor/datatables/dataTables.fixedColumns.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url('assets'); ?>/css/sb-admin.css" rel="stylesheet">

  <link href="<?php echo base_url('assets'); ?>/css/bootstrap-datetimepicker.min2.css" rel="stylesheet">
  <link href="<?php echo base_url('assets'); ?>/css/jquery-ui.css" rel="stylesheet">
  <link href="<?php echo base_url('assets'); ?>/css/chosen.css" rel="stylesheet">
   <link href="<?php echo base_url('assets'); ?>/css/custom.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <script src="<?php echo base_url('assets'); ?>/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url('assets'); ?>/js/jquery-ui.js"></script>
  <script type="text/javascript">
    var base_url = '<?php echo base_url(); ?>';
  </script>
  <script src="<?php echo base_url('assets/js/common.js'); ?>"></script>

  <div class="content-wrapper">
    <div class="container-fluid">
      <div class="card mb-3">
        <div class="card-header">
          <?php echo $heading; ?>
        </div>
        <div class="card-body">

<!-- Code added for loader from here -->

<style>
.loader {
    position: fixed;
    left: 0px;
    top: 0px;
    width: 100%;
    height: 100%;
    z-index: 9999;
    background: url("<?php echo base_url('assets/img/load.gif'); ?>") 50% 50% no-repeat rgba(0, 0, 0, 0.42);
    background-size: 140px;
}
</style>
<div id="loading" class="loader"></div>

<script type="text/javascript">
  $(document).ready(function() {
    $('#loading').hide();
    $.ajaxSetup({
      beforeSend:function(){
        $("#loading").show();
      },
      complete:function(){
        $("#loading").hide();
      }
    });
  });

 /* $(document).ajaxError(function(){
    alert("Error posting feed.");
    return false;
  });*/
</script>

<!-- Code adde for loader -->
<?php
  $this->load->view('include/menubar');
  $this->load->view($view, $data);
  $this->load->view('include/footer');
?>