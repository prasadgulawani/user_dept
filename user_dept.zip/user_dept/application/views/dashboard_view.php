<form method="post" id="save_user" enctype="multipart/form-data">
  <div class="row form-group col-sm-12">
    <label class="col-sm-3">
      User Name
    </label>
  	<div class="col-sm-3">
      <label>
        <?php echo @$user['first_name']; ?>
      </label>
      <label>
        <?php echo @$user['last_name']; ?>
      </label>
    </div>

    <label class="col-sm-3">
      User Email
    </label>
    <div class="col-sm-3">
      <label>
        <?php echo @$user['email']; ?>
        <input type="hidden" name="id" value="<?php echo @$user['id']; ?>">
      </label>
    </div>
  </div>

  <div class="row form-group col-sm-12">
    <label class="col-sm-3">
      User Department
    </label>
    <div class="col-sm-3">
      <label>
        <?php echo (isset($user['department'])) ? $user['department']: '-NA-'; ?>
      </label>
    </div>

    <label class="col-sm-3">
      Select Department
    </label>
    <div class="col-sm-3">
      <select class="form-control chosen-select" name="dept_id" id="dept_id">
        <option value="" disabled selected>Select Department</option>
      </select>
    </div>
  </div>

  <div class="row form-group col-sm-12">
    <label class="col-sm-3">
      User Sub Department
    </label>
    <div class="col-sm-3">
      <label>
        <?php echo (isset($user['sub_department'])) ? $user['sub_department']: '-NA-'; ?>
      </label>
    </div>

    <label class="col-sm-3">
      Select Sub Department
    </label>
    <div class="col-sm-3">
      <select class="form-control chosen-select" name="sub_dept_id" id="sub_dept_id">
        <option value="" disabled selected>Select Sub Department</option>
      </select>
    </div>
  </div>

  <div class="row form-group col-sm-12">
    <label class="col-sm-3">
      User Photo
    </label>
    <div class="col-sm-3">
      <?php if(!empty($user['image'])) { ?>
        <img height="200px" width="200px" src="<?php echo base_url('assets/img/').$user['image']; ?>" alt="<?php echo base_url('assets/img/').$user['image']; ?>" />
      <?php } else { ?>
        <label>-NA-</label>
      <?php } ?>
    </div>

    <label class="col-sm-3">
      Select User Photo
    </label>
    <div class="col-sm-3">
      <input type="file" id="user_img" name="userfile" accept='image/*' />
    </div>
  </div>

  <div class="row form-group col-sm-12 text-center" style="display: block;">
    <button type="submit" class="btn btn-primary" id="btn_save_user">Submit</button>
  </div>
</form>
<script type="text/javascript">
	$(document).ready(function()
	{
    $('.chosen-select').chosen();
		getDepartments();
	});

  function getDepartments()
  {
    $.ajax({
      type: "POST",
      url: base_url+'dashboard/getDepartments',
      dataType: "json",
      success: function(response)
      {
        var departments = '<option value="" selected disabled>Select Department</option>';
        var data = response.data;
        if (data.length > 0)
        {
          $.each(data, function (kqy, val) {
            departments += '<option value="'+val.id+'">'+val.dept_name+'</option>';
          });
        }
        else
        {
          departments = '<option disabled>No records found</option>';
        }
        $('#dept_id').html(departments);
        $('#dept_id').trigger('chosen:updated');
      },
      error: function(response)
      {
        alert('Error posting feeds.');
        return false;
      }
    });
  }

  $(document).on('change', '#dept_id', function()
  {
    getSubDepartments();
  });

  function getSubDepartments()
  {
    var dept_id = $.trim($('#dept_id').val());
    if(dept_id != '')
    {
      $.ajax({
        type: "POST",
        url: base_url+'dashboard/getSubDepartments',
        dataType: "json",
        data: {'dept_id': dept_id},
        success: function(response)
        {
          if(response.status == true)
          {
            var sub_departments = '<option value="" selected disabled>Select Sub Department</option>';
            var data = response.data;
            if (data.length > 0)
            {
              $.each(data, function (kqy, val) {
                sub_departments += '<option value="'+val.id+'">'+val.sub_dept_name+'</option>';
              });
            }
            else
            {
              sub_departments = '<option disabled>No records found</option>';
            }
            $('#sub_dept_id').html(sub_departments);
            $('#sub_dept_id').trigger('chosen:updated');
          }
          else
          {
            alert(response.message);
            return false;
          }
        },
        error: function(response)
        {
          alert('Error posting feeds.');
          return false;
        }
      });
    }
  }

  $('#save_user').on('submit', function(e) {
    e.preventDefault();
    if($.trim($('#dept_id').val()) == '' && $.trim($('#sub_dept_id').val()) == '' && $.trim($('#user_img').val()) == '')
    {
      alert("Please Select Department, Sub Department or Photo.");
      return false;
    }
    else
    {
      $('#btn_save_user').attr('disabled', true);
      var formdata = new FormData($('#save_user')[0]);
      $.ajax({
        type: "POST",
        url: base_url+'dashboard/updateUser',
        data: formdata,
        contentType: false,
        processData: false,
        dataType: "json",
        success: function(response)
        {
          alert(response.message);
          if(response.status == true)
          {
            window.location.reload();
          }
        },
        error: function(response)
        {
          alert('Error posting feeds.');
          return false;
        }
      });
    }
  });

  $('#user_img').bind('change', function() {
    var ext = $('#user_img').val().split('.').pop().toLowerCase();
    if ($.inArray(ext, ['png','jpg','jpeg']) == -1)
    {
      alert("Please upload JPG or PNG only.");
      $('#user_img').val('');
    }
  });
</script>