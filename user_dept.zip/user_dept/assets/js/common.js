$(document).on('keydown','.integer',function(e){
    // between 0 and 9
	if (e.which < 48 || e.which > 57)
	{
		// showAdvice(this, "Integer values only");
		return(false); // stop processing
	}
});

 function validateEmail($email) {
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  return emailReg.test( $email );
}
